INTERIOR IS LOCATED AT:
50, -977, -95
https://discord.com/invite/c7kphXJgbt